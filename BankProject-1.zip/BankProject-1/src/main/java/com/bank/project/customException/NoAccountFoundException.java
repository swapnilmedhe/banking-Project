
package com.bank.project.customException;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
@Component
public class NoAccountFoundException extends RuntimeException{

	private HttpStatus status;
	private String msg;

	public NoAccountFoundException() {
		// TODO Auto-generated constructor stub
	}
	public NoAccountFoundException(HttpStatus status, String msg) {
		super();
		this.status = status;
		this.msg = msg;
	}
	public HttpStatus getStatus() {
		return status;
	}
	public void setStatus(HttpStatus status) {
		this.status = status;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}




}
