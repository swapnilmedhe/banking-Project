package com.bank.project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.bank.project.customException.EmptyInputException;
import com.bank.project.customException.NoAccountFoundException;
import com.bank.project.customException.NoUsersFound;
import com.bank.project.entity.Account;
import com.bank.project.entity.User;
import com.bank.project.repository.AccountRepository;
import com.bank.project.repository.UserRepository;



@Service
public class AccountService
{
	@Autowired
	AccountRepository arepo;
	@Autowired
	UserRepository urepo;

	public List<Account> getAll()
	{
		List<Account> list=arepo.findAll();
		if(list.isEmpty())
			throw new NoAccountFoundException();
		else
			return list;

	}

	public Account getAccountById(int account_id)
	{
		Account ac=arepo.findById(account_id).get();
		if(ac!=null)
			return ac;
		else
			throw new NoAccountFoundException(HttpStatus.NOT_FOUND,"No account found ");
	}

	public Account addAccount(Account account)
	{
		//System.out.println("userd id from user"+account.getUser().getName()+" "+account.getUser().getUser_ID());
		if(account.getBranch_Name().isEmpty())
			throw new EmptyInputException();
		else
			return arepo.save(account);
	}


	public void updateAccount(Account account, int id) 
	{
		if(arepo.findById(id)!=null) {
			arepo.updateUserByID(id,account.getBranch_Name(), account.getAccount_type(),
					account.getAccount_balance(),account.getUser());
		}
		else
			throw new NoAccountFoundException();

	}

	public void deleteAccountById(int id) 
	{
		if(arepo.findById(id)!=null) 
		{
			arepo.deleteById(id);
		}
		else
			throw new NoAccountFoundException();

	}
}
