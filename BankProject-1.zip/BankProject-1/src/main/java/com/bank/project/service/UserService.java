package com.bank.project.service;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.bank.project.customException.EmptyInputException;
import com.bank.project.customException.NoUsersFound;
import com.bank.project.entity.Account;
import com.bank.project.entity.User;
import com.bank.project.repository.AccountRepository;
import com.bank.project.repository.UserRepository;


@Service
public class UserService 
{
	@Autowired
	UserRepository urepo;
	@Autowired
	AccountRepository arepo;
	
	public User save(User u) throws ParseException  
	{
		List<Account> arr=u.getAccount();
		System.out.println(arr.toString());
		
		
		if(!(u.getName().isEmpty() || u.getName().length()==0))
		{
		
			String s=u.getDOB().toString();
			User us=new User(u.getName(), u.getEmail_ID(), u.getMobile_number(), u.getSecondary_Mobile(), 
					s,u.getGender(),arr);
			//u.setAccount(arr);
			return urepo.save(us);
		}
		else
			throw new EmptyInputException();
	}

	public User getUserById(int User_ID)
	{
		Optional<User> u=urepo.findById(User_ID);
		if(u!=null)
			return u.get();
		else
			throw new NoUsersFound();
	}
	
	public List<User> getAll()
	{
		List<User> all=urepo.findAll();
		if(urepo.findAll().isEmpty())
			throw new NoUsersFound();
		else	
		return urepo.findAll();
	}
	
	public void DeleteByID(int User_ID) 
	{
		Optional<User> u=urepo.findById(User_ID);	//to avoid null check
		//u.get();
		if(u!=null)
			urepo.deleteById(User_ID);
		else
			throw new NoUsersFound();
	}

	public void updateUser(User user,int id) 
	{
		User ex=urepo.findById(id).get();
		if(ex==null) {
			throw new NoUsersFound();
			
			
		}
		else {
			/*
			  ex.setDOB(user.getDOB()); ex.setEmail_ID(user.getEmail_ID());
			  ex.setGender(user.getGender()); ex.setMobile_number(user.getMobile_number());
			  ex.setName(user.getName());
			  ex.setSecondary_Mobile(user.getSecondary_Mobile()); ex.setUser_ID(id);
			  urepo.save(ex);
			 */
		
		urepo.updateUserByID(id,user.getName(),user.getEmail_ID(),user.getMobile_number(),
				user.getSecondary_Mobile(),user.getDOB(),user.getGender());
				
		}

	}
}
