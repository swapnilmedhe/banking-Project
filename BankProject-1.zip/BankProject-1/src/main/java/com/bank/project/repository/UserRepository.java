package com.bank.project.repository;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bank.project.entity.User;

@Transactional
@Repository
public interface UserRepository extends JpaRepository<User, Integer>
{
	
	/*
	  @Modifying
	  
	  @Query(value=" delete from user where User_ID=?1",nativeQuery = true) public
	  int deleteUserById(int User_ID);
	 */
	
	@Modifying
	@Query(value=" update user set Name=?2,Email_ID=?3,Mobile_number=?4,Secondary_Mobile=?5,DOB=?6,Gender=?7 where User_ID=?1 ",nativeQuery = true)
	public int updateUserByID(int id,String name, String email_ID, String mobile_number, String secondary_Mobile, Date dob,
			char gender);
	
}
