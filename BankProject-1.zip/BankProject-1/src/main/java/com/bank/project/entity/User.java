package com.bank.project.entity;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.springframework.lang.NonNull;


@Entity
@Table(name="User")
public class User 
{
//	-- User_ID -- Primary Key -- numeric(5)
//	-- Name   -- 40 Chars
//	-- Email_ID   -- 100 cars
//	-- Mobile number -- 10 char
//	-- Secondary _Mobile -- 10 char
//	-- DOB --String format"DD-MMM-YYYY"
//	-- Gender -- (M/F) -- single Char

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int User_ID;
	@Column
	String Name;
	//@Email(message = "Invalid email Address")
	//@NotBlank(message = "Invalid email Address")
	String Email_ID;
	@Pattern(regexp = "^[0-9]{10}$",message = "Invalid mobile number")
	String Mobile_number;
	@Pattern(regexp = "^[0-9]{10}$",message = "Invalid secondary mobile number")
	String Secondary_Mobile;
	@Column
	//@Pattern(regexp = "^[mMFf][1]$",message = "Invalid secondary mobile number")
	char Gender;
	@Column
	Date DOB;

	@OneToMany(mappedBy = "user",cascade = CascadeType.ALL)
	@Column(nullable = true)
	List<Account> Account;
	
	public User() {
		super();
	}

	public User(String name, String email_ID, String mobile_number, String secondary_Mobile, String dOB,
			char gender, List<Account> account) throws ParseException {
		super();
		//User_ID = user_ID;
		Name = name;
		Email_ID = email_ID;
		Mobile_number = mobile_number;
		Secondary_Mobile = secondary_Mobile;
		this.DOB = new Date(new SimpleDateFormat("yyyy-mm-dd").parse(dOB).getDate());
		Gender = gender;
		Account = account;
	}

	public User(int id,String name,@Email String email_ID, @Pattern(regexp = "^[0-9]{10}$") String mobile_number,@Pattern(regexp = "^[0-9]{10}$") String secondary_Mobile, String dOB,
			char gender, List<Account> account) throws ParseException {
		super();
		User_ID = id;
		Name = name;
		Email_ID = email_ID;
		Mobile_number = mobile_number;
		Secondary_Mobile = secondary_Mobile;
		DOB = new Date(new SimpleDateFormat("yyyy-mm-dd").parse(dOB).getDate());
		Gender = gender;
		Account = account;
	}
	public int getUser_ID() {
		return User_ID;
	}

	public void setUser_ID(int user_ID) {
		User_ID = user_ID;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getEmail_ID() {
		return Email_ID;
	}

	public void setEmail_ID(String email_ID) {
		Email_ID = email_ID;
	}

	public String getMobile_number() {
		return Mobile_number;
	}

	public void setMobile_number(String mobile_number) {
		Mobile_number = mobile_number;
	}

	public String getSecondary_Mobile() {
		return Secondary_Mobile;
	}

	public void setSecondary_Mobile(String secondary_Mobile) {
		Secondary_Mobile = secondary_Mobile;
	}

	public Date getDOB() {
		return DOB;
	}

	public void setDOB(Date dOB) {
		DOB = dOB;
	}

	public char getGender() {
		return Gender;
	}

	public void setGender(char gender) {
		Gender = gender;
	}

	public List<Account> getAccount() {
		return Account;
	}

	public void setAccount(List<Account> account) {
		Account = account;
	}

	@Override
	public String toString() {
		return "User [User_ID=" + User_ID + ", Name=" + Name + ", Email_ID=" + Email_ID + ", Mobile_number="
				+ Mobile_number + ", Secondary_Mobile=" + Secondary_Mobile + ", DOB=" + DOB + ", Gender=" + Gender
				+ ", Account=" + Account + "]";
	}

	
	
	

}