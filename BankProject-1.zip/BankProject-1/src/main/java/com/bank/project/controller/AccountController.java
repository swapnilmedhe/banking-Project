package com.bank.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bank.project.entity.Account;
import com.bank.project.service.AccountService;


@CrossOrigin(value = "*")
@RestController
@RequestMapping("/account")
public class AccountController 
{
	@Autowired
	AccountService aservice;

	@GetMapping("/allAccounts")
	public ResponseEntity<List<Account>> fetch()
	{
		List<Account> listOfAllAccounts = aservice.getAll();
		return new ResponseEntity<List<Account>>(listOfAllAccounts, HttpStatus.OK);

	}

	@GetMapping("/getAcc/{account_id}")
	public ResponseEntity<Account> getAccountById(@PathVariable("account_id") int id)
	{
		Account ac=aservice.getAccountById(id);
		return new ResponseEntity<Account>(ac,HttpStatus.FOUND);
	}

	//public ResponseEntity<?> addAccount(@RequestBody Account account)
	@PostMapping("/addAccount")
	public ResponseEntity<?> addAccount(@RequestBody Account account)
	{
		//System.out.println(account.getBranch_Name());
		if(account!=null) {
		Account ac=aservice.addAccount(account);
		return new ResponseEntity<String>("Account has been added successFully",HttpStatus.CREATED);
		}else
			return null;
	}

	@PutMapping("/updateAccount/{id}")
	public ResponseEntity<?> updateAccount(@PathVariable ("id") int id,@RequestBody Account account)
	{
		//System.out.println("account name"+account.getAccount_balance());
			aservice.updateAccount(account,id);
			return new ResponseEntity<String>("Account update successfully",HttpStatus.OK);
		

	}

	@DeleteMapping("/deleteAccount/{id}")
	public ResponseEntity<?> deleteAccount(@PathVariable ("id") int id)
	{
		aservice.deleteAccountById(id);
		return new ResponseEntity<String>("Account deleted successfully",HttpStatus.OK);
	}
}
